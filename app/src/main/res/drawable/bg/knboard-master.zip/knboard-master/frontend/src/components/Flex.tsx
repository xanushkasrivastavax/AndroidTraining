import styled from "@emotion/styled";

const Flex = styled.div`
  display: flex;
  justify-content: space-between;
`;

export default Flex;
