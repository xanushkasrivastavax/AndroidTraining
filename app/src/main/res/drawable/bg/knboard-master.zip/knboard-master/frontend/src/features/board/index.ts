export { default } from "./Board";
