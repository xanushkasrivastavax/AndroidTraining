/* istanbul ignore file */
import React from "react";
import ReactDOM from "react-dom";
import "react-markdown-editor-lite/lib/index.css";
import "./index.css";
import App from "./App";

ReactDOM.render(<App />, document.getElementById("root"));
